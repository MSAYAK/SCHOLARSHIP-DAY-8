package com.lnt.mvc.service;

import java.util.List;

import com.lnt.mvc.model.Registration;

public interface RegistrationService {
public void save(Registration r);

 //public List<String> fetchInstitutename();
}

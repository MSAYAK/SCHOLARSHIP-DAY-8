package com.lnt.mvc.service;

import java.util.List;

//import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lnt.mvc.dao.StudentRegistrationDao;
import com.lnt.mvc.model.ScholarshipApplicationForm;
import com.lnt.mvc.model.StudentRegistration;
@Service
public class StudentRegistrationServiceImpl implements StudentRegistrationService{
@	Autowired	
private StudentRegistrationDao studentRegistrationDao;

public void setStudentRegistrationDao(StudentRegistrationDao studentRegistrationDao) {
	this.studentRegistrationDao = studentRegistrationDao;
}

@Override
@Transactional
public void save(StudentRegistration s) {
 this.studentRegistrationDao.save(s);
	
}

@Override
public boolean verifyUser(Integer aadharno, String password) {
	return this.studentRegistrationDao.verifyUser(aadharno, password);
}

@Override
public boolean verifyMinister(String username, String password) {

	return this.studentRegistrationDao.verifyMinister(username, password);
}

@Override
public boolean verifyOfficer(String officerusername, String officerpassword) {
	
	return this.studentRegistrationDao.verifyOfficer(officerusername, officerpassword);
}

@Override
public boolean verifyInstitute(String In_Name, String Password) {
	return this.studentRegistrationDao.verifyInstitute(In_Name, Password);
}

@Override
public void getById(Integer aadharno) {
	this.studentRegistrationDao.getById(aadharno);
	
}

@Override
public StudentRegistration getStudent(int aadharno, String password) {
	// TODO Auto-generated method stub
	return this.studentRegistrationDao.getStudent(aadharno, password);
}

	/*
	 * @Override public List<ScholarshipApplicationForm> applicationform() {
	 * 
	 * return this.studentRegistrationDao.applicationform(); }
	 */

 
	

}

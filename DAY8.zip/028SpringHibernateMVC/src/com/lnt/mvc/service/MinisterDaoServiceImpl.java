package com.lnt.mvc.service;





	import java.util.List;

	import javax.transaction.Transactional;

	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.stereotype.Service;

	import com.lnt.mvc.dao.MinisterDao;
	import com.lnt.mvc.model.ScholarshipApplicationForm;
	@Service
	public class MinisterDaoServiceImpl implements MinisterDaoService {
	private MinisterDao ministerDao; 
	@Autowired
	public void setMinisterDao(MinisterDao ministerDao) {
	this.ministerDao = ministerDao;
	}


	@Override
	@Transactional
	public List<ScholarshipApplicationForm> listapplications() {
	 
	return this.ministerDao.listapplications();
	}


	@Override
	public void acceptApplicaton(int studentId) {
	this.ministerDao.acceptApplicaton(studentId);
	}


	@Override
	public void rejectApplication(int studentId) {
	this.ministerDao.rejectApplication(studentId);
	}


	@Override
	public ScholarshipApplicationForm getApplication(int studentId) {
	 
	return this.ministerDao.getApplication(studentId);
	}

	}

	
	


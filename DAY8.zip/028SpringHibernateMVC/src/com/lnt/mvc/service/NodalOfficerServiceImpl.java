package com.lnt.mvc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lnt.mvc.dao.NodalOfficerDao;
import com.lnt.mvc.model.FinalApplication;

@Service
public class NodalOfficerServiceImpl implements NodalOfficerService{
@Autowired
private NodalOfficerDao nodalOfficerDao;
public void setNodalOfficerDao(NodalOfficerDao nodalOfficerDao) {
this.nodalOfficerDao = nodalOfficerDao;
}

@Override
public List<FinalApplication> application() {
 
return this.nodalOfficerDao.applications();
}

@Override
public void acceptApplicaton(int studentId) {
this.nodalOfficerDao.acceptApplicaton(studentId);
}

@Override
public void rejectApplication(int studentId) {
this.nodalOfficerDao.rejectApplication(studentId);
}

@Override
public FinalApplication getApplication(int studentId) {
 
return nodalOfficerDao.getApplication(studentId);
}

}

package com.lnt.mvc.dao;
import java.util.List;

import com.lnt.mvc.model.FinalApplication;

public interface NodalOfficerDao {

public List<FinalApplication>applications();

public void acceptApplicaton(int studentId);
public void rejectApplication(int studentId);
public FinalApplication getApplication(int studentId);



}

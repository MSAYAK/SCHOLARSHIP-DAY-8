package com.lnt.mvc.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lnt.mvc.model.ScholarshipApplicationForm;
@Repository
public class DocumentsUploadDaoImpl implements DocumentsUploadDao {
	
	private static final Logger logger = 			
			LoggerFactory.getLogger(PersonDaoImpl.class);
	@Autowired
	private SessionFactory sessionFactory;
	public void setSessionFactory(SessionFactory sf) {
		this.sessionFactory = sf;
	}	

	
	@Override
	
	public void save(ScholarshipApplicationForm scholarshipform) {
		
		
		Session session = this.sessionFactory.openSession();
		System.out.println("data entering");
		Transaction tx=session.beginTransaction();
		session.save(scholarshipform);
		System.out.println("Saved Data");
		logger.info("Scholarshipdetails saved successfully,Scholarship Details="
		+ scholarshipform);
		tx.commit();
		
		session.close();
	}

	
	  @Override
	  
	@Transactional public List<ScholarshipApplicationForm> list() {

	  Session session =sessionFactory.openSession();
	  List<ScholarshipApplicationForm>applications=null;
	  try {
	 applications=(List<ScholarshipApplicationForm>)session.
			 createQuery("from ScholarshipApplicationForm").list(); }
	  catch(HibernateException e) { System.out.println("dfjkgj");
	  e.printStackTrace(); }
	
	  return applications; }
	
	 @Override public void remove(Integer id) {

	 Session session= sessionFactory.openSession(); ScholarshipApplicationForm
	  applicationForm
	 =(ScholarshipApplicationForm)session.get(ScholarshipApplicationForm.class,id)
	  ; session.delete(applicationForm); }
	
	 @Override public ScholarshipApplicationForm get(Integer id) {

	 Session session=sessionFactory.openSession(); ScholarshipApplicationForm
	  applicationForm=(ScholarshipApplicationForm)session.get(
	  ScholarshipApplicationForm.class,id); session.close();
	
	 return applicationForm; }
	

}
 
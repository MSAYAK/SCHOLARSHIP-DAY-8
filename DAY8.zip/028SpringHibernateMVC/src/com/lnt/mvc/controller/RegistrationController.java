package com.lnt.mvc.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.lnt.mvc.exception.CustomException;
import com.lnt.mvc.model.Person;
//import com.lnt.mvc.model.Person;
import com.lnt.mvc.model.Registration;
import com.lnt.mvc.model.ScholarshipApplicationForm;
import com.lnt.mvc.model.StudentRegistration;
import com.lnt.mvc.service.DocumentsUploadService;
import com.lnt.mvc.service.RegistrationService;

@Controller
public class RegistrationController {
@Autowired	
private RegistrationService registrationService;
@Autowired
private DocumentsUploadService documentsUploadService; 

 
public void setDocumentsUploadService(DocumentsUploadService documentsUploadService) {
	this.documentsUploadService = documentsUploadService;
}
public void setRegistrationService(RegistrationService registrationService) {
	this.registrationService = registrationService;
}
@RequestMapping(value="/institutes")
public String registerdetails(Model model) {
		/*
		 * List<String>in_Name=registrationService.fetchInstitutename();
		 * model.addAttribute("instituteList",in_Name);
		 */
		 
model.addAttribute("institute",new Registration());

return "institute";
}


@RequestMapping(value="/institute/save",
method=RequestMethod.POST)
public String save(
		@ModelAttribute("institute")
		@Valid Registration r,
		BindingResult result,
		Model model) {
		if(!result.hasErrors()) {
			
			
			this.registrationService.save(r);
		}

		return "redirect:/";

}





@RequestMapping(value="/scholarship/save",
method=RequestMethod.POST)
public String savescholarship(
		@ModelAttribute("document")
		@Valid ScholarshipApplicationForm scholarshipform,
		BindingResult result,
		Model model) {
		if(!result.hasErrors()) {
			
			
			this.documentsUploadService.save(scholarshipform);
		}


		return "dash";

}

}
 
		
		


	
	
	
			




